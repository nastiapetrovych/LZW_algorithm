import sys
from Greyscale2 import GrayscaleImageADT

d = GrayscaleImageADT(4, 5)
d.from_file('sea.jpg')
c = d.image.shape
first = len(d.image) * len(d.image[0])
second = d.lzw_compression()
second = len(second)
print(f'The difference : {first - second} ')
