from io import StringIO
import numpy as np
from PIL import Image, ImageOps
"""
The task for operating the black-white images
"""


class GrayscaleImageADT:
    """
    Operates  images
    """
    def __init__(self, n_rows, n_cols):
        """
        The creation of a default array
        :param n_rows: int
        :param n_cols: int
        """
        self.n_rows, self.n_cols = n_rows, n_cols
        self.image = np.zeros((self.n_rows, self.n_cols))

    def width(self):
        """
        Returns the width of the image
        :return: int
        """
        return self.n_rows

    def height(self):
        """
        Returns the height of the image
        :return: int
        """
        return self.n_cols

    def clear(self, value):
        """
        Put this value into correct position. The value > 0 < 255
        :param value: int
        :return: None
        """
        rows = self.width()
        cols = self.height()
        if 0 <= value < 256:
            for row in range(rows):
                for col in range(cols):
                    self.image[row, col] = value
        else:
            return 'The value is not correct'

    def get_item(self, row, col):
        """
        Returns the current pixel
        :param row: int
        :param col: int
        :return: int
        """
        try:
            return self.image[row, col]
        except IndexError:
            return'The index is out of range'

    def setitem(self, row, col, value):
        """
        Sets the value of a current pixel
        :param row: int
        :param col: int
        :param value: int
        :return: None
        """
        if 0 <= value < 256:
            try:
                self.image[row, col] = value
            except IndexError:
                return 'The index is out of range'
        else:
            return 'The value is not correct'

    def from_file(self, path):
        """
        Converts the image into array
        :param path:
        :return:
        """
        if path.lower().endswith(('.png', '.jpg')):
            try:
                image = Image.open(path)
            except FileNotFoundError:
                return "File is not found"
        else:
            return 'It is not a right image extension'
        image_grayscale = ImageOps.grayscale(image)
        self.image = np.array(image_grayscale)
        self.n_cols = len(self.image[0])
        self.n_rows = len(self.image)

    def lzw_compression(self):
        """
        Compress image with LZW algorythm
        Example of work of algorythm is here:
        ABACBAD  => [A=0, B=1, C = 2, D = 3, AB = 4, BA = 5, AC = 6, CB = 7, BAD = 8]
        [0, 1, 0, 2, 5, 3]
        :return:list
        """
        dict_size = 256
        dict_name = {chr(i): i for i in range(dict_size)}
        data = ''
        for row in range(self.width()):
            for col in range(self.height()):
                data += chr(self.get_item(row, col))
        txt = ''
        result = []
        for character in data:
            extra_character = txt + character
            if extra_character in dict_name:
                txt = extra_character
            else:
                result.append(dict_name[txt])
                dict_name[extra_character] = dict_size
                dict_size += 1
                txt = character
        if txt:
            result.append(dict_name[txt])
        self.image = result
        return result

    def lzw_decompression(self):
        """
        Decompress the list of numbers into text with help of LZW algorythm
        Example of work:
        [0, 1, 0, 2, 5, 3] => [A=0, B=1, C = 2, D = 3, AB = 4, BA = 5]
        ABACBAD
        :return: list
        """
        dict_size = 256
        dict_name = dict((i, chr(i)) for i in range(dict_size))
        txt = StringIO()
        character = chr(self.image.pop(0))
        txt.write(character)
        for extra_character in self.image:
            if extra_character in dict_name:
                info = dict_name[extra_character]
            elif extra_character == dict_size:
                info = character + character[0]
            else:
                raise ValueError('Bad compressed value')
            txt.write(info)
            dict_name[dict_size] = character + info[0]
            dict_size += 1
            character = info
        lst = txt.getvalue()
        lst = [ord(i) for i in lst]
        res = np.reshape(lst, (self.n_rows, self.n_cols))
        return res

# d = GrayscaleImageADT(4,5)
# d.from_file('sea.jpg')
# first = d.image
# first = d.image
# d.lzw_compression()
# second = d.lzw_decompression()
# print(second == first)
# test_img = Image.fromarray(second.astype('uint8'))
# test_img.show()
